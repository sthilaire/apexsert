PROMPT == LAUNCH_APEX-SERT
@prc/launch_sert.pls
/
SHOW ERRORS 
/