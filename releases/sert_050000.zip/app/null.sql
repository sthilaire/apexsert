PROMPT..
-- NULL.SQL  
-- Used to do "nothing" in the case where a script should not be executed.